var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var publicClass = (function () {
    function publicClass() {
    }
    publicClass.loadingLogo = false;
    return publicClass;
}());
__reflect(publicClass.prototype, "publicClass");
var publicFun = (function () {
    function publicFun() {
    }
    //位图
    publicFun.createBitmapByName = function (name) {
        var result = new egret.Bitmap();
        var texture = RES.getRes(name);
        result.texture = texture;
        return result;
    };
    publicFun.ins = 1;
    return publicFun;
}());
__reflect(publicFun.prototype, "publicFun");
//# sourceMappingURL=publicClass.js.map