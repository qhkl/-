var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var huanZhuang = (function (_super) {
    __extends(huanZhuang, _super);
    function huanZhuang() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    huanZhuang.prototype.createChildren = function () {
        //方法1
        //this.setNewSlot( "xiangl1" , "on_png",armature );
        this.addEventListener(eui.UIEvent.COMPLETE, this.onComplete, this);
        //this.skinName = "resource/assets/sceneGame/sceneSkinGameRen.exml";
        this.onComplete();
    };
    huanZhuang.prototype.onComplete = function () {
        var armature = Object(this.parent.parent).factory.buildArmature("sc" + publicFun.ins + "Renwu1");
        this.armatureClip = armature.getDisplay();
        dragonBones.WorldClock.clock.add(armature);
        this.armatureClip.x = 0;
        this.armatureClip.y = 0;
        this.addChild(this.armatureClip);
        armature.animation.play();
        this.shoull = [armature.getBone("shoul1"), armature.getBone("shoul2"), armature.getBone("shoul3"), armature.getBone("shoul4"), armature.getBone("shoul5")];
        this.ershil = [armature.getBone("ershi1"), armature.getBone("ershi2"), armature.getBone("ershi3"), armature.getBone("ershi4"), armature.getBone("ershi5")];
        this.xiangl = [armature.getBone("xiangl1"), armature.getBone("xiangl2"), armature.getBone("xiangl3"), armature.getBone("xiangl4"), armature.getBone("xiangl5")];
        this.jiezhil = [armature.getBone("jiezhi1"), armature.getBone("jiezhi2"), armature.getBone("jiezhi3"), armature.getBone("jiezhi4"), armature.getBone("jiezhi5")];
        for (var i = 0; i < this.xiangl.length; i++) {
            this.xiangl[i].visible = false;
            this.shoull[i].visible = false;
            this.ershil[i].visible = false;
            this.jiezhil[i].visible = false;
        }
        this.setChildIndex(this.armatureClip, 0);
    };
    huanZhuang.prototype.update = function (e, j) {
        var eps;
        if (j == "btn1") {
            eps = this.shoull;
        }
        if (j == "btn2") {
            eps = this.ershil;
        }
        if (j == "btn3") {
            eps = this.xiangl;
        }
        if (j == "btn4") {
            eps = this.jiezhil;
        }
        for (var i = 0; i < eps.length; i++) {
            eps[i].visible = false;
        }
        eps[e].visible = true;
    };
    huanZhuang.prototype.removedate = function (e) {
        for (var i = 0; i < this.xiangl.length; i++) {
            this.xiangl[i].visible = false;
        }
    };
    huanZhuang.prototype.removeChildFun = function () {
        if (this.armatureClip) {
            this.removeChild(this.armatureClip);
            this.armatureClip = null;
        }
    };
    return huanZhuang;
}(eui.Component));
__reflect(huanZhuang.prototype, "huanZhuang");
//# sourceMappingURL=lei.js.map