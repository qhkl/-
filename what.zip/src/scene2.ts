class Scene2 extends eui.Component {
    private onComplete():void{
        //
        this.start.addEventListener( egret.TouchEvent.TOUCH_END,this.TouchFun,this);
        //
        for(var i=1;i<=4;i++)
        {
            this.mu.getChildByName("Bju1").getChildByName("btn"+i).addEventListener( egret.TouchEvent.TOUCH_END,this.TouchFun,this);
        }
        for(i=1;i<=2;i++)
        {
            this.mu.getChildByName("Bju2").getChildByName("btn"+i).addEventListener( egret.TouchEvent.TOUCH_END,this.TouchFun,this);
        }
        for(i=1;i<=4;i++)
        {
            this.mu.getChildByName("Bju3").getChildByName("btn"+i).addEventListener( egret.TouchEvent.TOUCH_END,this.TouchFun,this);
        }
        this.shoufouBoo=[false,false,false];
    }
    private shoufouBoo:Array<boolean>=[];
    private btn1;
    private mu;
    private start;
    private TouchFun(evt:egret.TouchEvent): void {
        if(evt.currentTarget.name=="start")
        {
            var tongjiBoo=0;
            for(i=0;i<this.shoufouBoo.length;i++)
            {
                if(this.shoufouBoo[i])
                {
                    tongjiBoo++;
                }
            }
            if(tongjiBoo==this.shoufouBoo.length)
            {
                Object(this.parent).sceneFun("Scene3",false,false);
            }
        }
        else
        {
            if(evt.currentTarget.parent.name=="Bju1")
            {
                for(var i=1;i<=4;i++)
                {
                    var arrLs:Array<string>=this.mu.getChildByName("Bju1").getChildByName("btn"+i).source.split("_");
                    if(arrLs.length>=3)
                    {
                        this.mu.getChildByName("Bju1").getChildByName("btn"+i).source=arrLs[0]+"_"+arrLs[2];
                    }
                }
                this.shoufouBoo[0]=true;
            }
            if(evt.currentTarget.parent.name=="Bju2")
            {
                for(i=1;i<=2;i++)
                {
                    var arrLs:Array<string>=this.mu.getChildByName("Bju2").getChildByName("btn"+i).source.split("_");
                    if(arrLs.length>=3)
                    {
                        this.mu.getChildByName("Bju2").getChildByName("btn"+i).source=arrLs[0]+"_"+arrLs[2];
                    }
                }
                this.shoufouBoo[1]=true;
            }
            if(evt.currentTarget.parent.name=="Bju3")
            {
                for(i=1;i<=4;i++)
                {
                    var arrLs:Array<string>=this.mu.getChildByName("Bju3").getChildByName("btn"+i).source.split("_");
                    if(arrLs.length>=3)
                    {
                        this.mu.getChildByName("Bju3").getChildByName("btn"+i).source=arrLs[0]+"_"+arrLs[2];
                    }
                }
                this.shoufouBoo[2]=true;
            }
            var arrLs:Array<string>=evt.currentTarget.source.split("_");
            if(arrLs.length<3)
            {
                evt.currentTarget.source=arrLs[0]+"_a_"+arrLs[1];
            }
        }
    }
    //
    public intFun()
    {
        this.shoufouBoo=[];
        this.shoufouBoo=[false,false,false];
        for(var i=1;i<=4;i++)
        {
            var arrLs:Array<string>=this.mu.getChildByName("Bju1").getChildByName("btn"+i).source.split("_");
            if(arrLs.length>=3)
            {
                this.mu.getChildByName("Bju1").getChildByName("btn"+i).source=arrLs[0]+"_"+arrLs[2];
            }
        }
        for(i=1;i<=2;i++)
        {
            var arrLs:Array<string>=this.mu.getChildByName("Bju2").getChildByName("btn"+i).source.split("_");
            if(arrLs.length>=3)
            {
                this.mu.getChildByName("Bju2").getChildByName("btn"+i).source=arrLs[0]+"_"+arrLs[2];
            }
        }
        for(i=1;i<=4;i++)
        {
            var arrLs:Array<string>=this.mu.getChildByName("Bju3").getChildByName("btn"+i).source.split("_");
            if(arrLs.length>=3)
            {
                this.mu.getChildByName("Bju3").getChildByName("btn"+i).source=arrLs[0]+"_"+arrLs[2];
            }
        }
    }
    public removeFun()
    {
        //
    }
    //-------------------------------/////-----------------------//
    protected createGameScene(): void {
        this.loadBoo = true;
        //
    }
    constructor() {
        super();
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
    }
    protected createChildren() {
        super.createChildren();
    }
    private onAddToStage(event: egret.Event) {
        //alert("sss");
        if(!this.loadBoo)
        {
            //
            this.stageW = this.stage.stageWidth;
            this.stageH = this.stage.stageHeight;
            //
            this.height=this.stageH;
            this.addEventListener(eui.UIEvent.COMPLETE,this.onComplete,this);
            this.skinName = "resource/assets/scene2/sceneSkin2.exml";
            //
            /*this.runGame().catch(e => {
                console.log(e);
            });*/
            this.loadBoo = true;
        }
        else
        {
            //
            //
        }
    }
    private async runGame() {
        await this.loadResource()
        this.createGameScene();
    }
    private async loadResource() {
        try {
            const loadingView = new LoadingUI();
            this.stage.addChild(loadingView);
            await RES.loadConfig("resource/default.res.json", "resource/");
            await RES.setMaxLoadingThread(6);
            await RES.loadGroup("scene1", 0, loadingView);
            this.stage.removeChild(loadingView);
        }
        catch (e) {
            console.error(e);
        }
    }
    private loadBoo = false;
    private stageW;
    private stageH;
}
