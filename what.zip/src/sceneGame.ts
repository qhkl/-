class SceneGame extends eui.Component {
    private LeftTiao;
    private foot;
    private mu;
    private tjiao;
    private onComplete():void{
        this.tjiao.addEventListener( egret.TouchEvent.TOUCH_END,this.TouchFun3,this);
        this.foot.source="sceneGameBoot"+publicFun.ins+"_png";
        this.LeftTiao.source="sceneGameLeftTiao"+publicFun.ins+"_png";

        this.huanZhuang = new huanZhuang();
        this.huanZhuang.width=750;
        this.huanZhuang.height=1624;
        this.huanZhuang.x = this.stageW*0.5;
        this.huanZhuang.y = this.stageH*0.5+(1624-this.stageH)/2-138;
        this.addChild(this.huanZhuang);
        this.setChildIndex(this.huanZhuang,0);
        
        for(var i=1;i<=4;i++)
        {
            var armature = Object(this.parent).factory.buildArmature("sc"+1+"Ybtn");
            var armatureClip = armature.getDisplay();
            dragonBones.WorldClock.clock.add(armature);
            this.mu.getChildByName("btn"+i).addChild(armatureClip);
            armatureClip.x=this.mu.getChildByName("btn"+i).width/2;
            armatureClip.y=this.mu.getChildByName("btn"+i).height/2;
            for(var j=1;j<=4;j++)
            {
                armature.getBone("btn"+j).visible=false;
                if(j==i)
                {
                    armature.getBone("btn"+j).visible=true;
                }
            }
            this.arrBtnImg.push(armatureClip);
            this.mu.getChildByName("btn"+i).addEventListener( egret.TouchEvent.TOUCH_END,this.TouchFun,this);
        }
    }
    private huanZhuang;
    private arrBtnImg:Array<any>=[];
    private TouchFun(evt:egret.TouchEvent): void {
        if(!this.wanChenBoo)
        {
            if(this.arrBtnImg.length>0)
            {
                if(this.topngjiDq!==evt.currentTarget)
                {
                    if(this.myAarmatureClip)
                    {
                        this.topngjiDq.removeChild(this.myAarmatureClip);
                        this.myAarmatureClip=null;
                    }
                    var str:string=evt.currentTarget.name.split("n")[1];
                    this.topngjiDq=evt.currentTarget;
                    var armature = Object(this.parent).factory.buildArmature("sc"+publicFun.ins+"Ebtn_"+str);
                    var armatureClip = armature.getDisplay();
                    dragonBones.WorldClock.clock.add(armature);
                    evt.currentTarget.addChild(armatureClip);
                    armatureClip.x=evt.currentTarget.width+50;
                    if(str=="1")
                    {
                        armatureClip.y=0;
                    }
                    if(str=="2")
                    {
                        armatureClip.y=-150;
                    }
                    if(str=="3")
                    {
                        armatureClip.y=-350;
                    }
                    if(str=="4")
                    {
                        armatureClip.y=-500;
                    }
                    armatureClip.touchEnabled = true;
                    armatureClip.addEventListener( egret.TouchEvent.TOUCH_END,this.TouchFun2,this);
                    this.songhua_MY=armature;
                    this.myAarmatureClip=armatureClip;
                }
            }
        }
    }
    private TouchFun3(evt:egret.TouchEvent): void {
        if(!this.wanChenBoo)
        {
            this.wanChenBoo=true;
            //
            var renderTexture = new egret.RenderTexture();

            renderTexture.drawToTexture(this.huanZhuang,new egret.Rectangle(-750/2,-1624/2+138,this.width,this.stageH));//渲染到临时画布

            var divImage = document.getElementById("divImage");//获取DIV
            var shareImage: HTMLImageElement = document.getElementById("shareImage") as HTMLImageElement;//获取Image标签
            shareImage.src = renderTexture.toDataURL('image/jpeg');//把数据赋值给Image
            divImage.style.display = "block";//显示DIV*/
            //this.intFun();
            this.divImage=true;
        }
        else
        {
            //alert(123);
        }
    }
    public Update(){
        var divImage = document.getElementById("divImage");//获取DIV
        if(this.divImage)
        {
            if(divImage.style.display == "none")
            {
                Object(this.parent).sceneFun("Scene1",true,false);
            }
        }
    }
    private divImage=false;
    private wanChenBoo=false;;
    private topngjiDq;
    private songhua_MY;
    private myAarmatureClip;
    private TouchFun2(evt:egret.TouchEvent): void {
        if(!this.wanChenBoo)
        {
            for(var i=1;i<=5;i++)
            {
                if(this.songhua_MY.getSlot("btn"+i).containsPoint(evt.localX,evt.localY))
                {
                    //alert(i);
                    this.huanZhuang.update((i-1),this.topngjiDq.name);
                }
            }
        }
    }
    //
    public intFun()
    {
    }
    public removeFun()
    {
        try{
            this.wanChenBoo=false;
            this.divImage=false;
            if(this.myAarmatureClip)
            {
                this.topngjiDq.removeChild(this.myAarmatureClip);
                this.myAarmatureClip=null;
            }
            if(this.huanZhuang)
            {
                this.huanZhuang.removeChildFun();
                this.removeChild(this.huanZhuang);
                this.huanZhuang=null;
            }
            if(this.arrBtnImg.length>0)
            {
                for(var i=0;i<this.arrBtnImg.length;i++)
                {
                    this.mu.getChildByName("btn"+(i+1)).removeChild(this.arrBtnImg[i]);
                }
                this.arrBtnImg=[];
            }
            this.topngjiDq=null;
            this.songhua_MY=null;
            this.myAarmatureClip=null;
        }
        catch(e)
        {

        }
    }
    //-------------------------------/////-----------------------//
    protected createGameScene(): void {
        this.loadBoo = true;
        //
    }
    constructor() {
        super();
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
    }
    protected createChildren() {
        super.createChildren();
    }
    private onAddToStage(event: egret.Event) {
        if(!this.loadBoo)
        {
            //
            this.stageW = this.stage.stageWidth;
            this.stageH = this.stage.stageHeight;
            //
            this.height=this.stageH;
            this.addEventListener(eui.UIEvent.COMPLETE,this.onComplete,this);
            this.skinName = "resource/assets/sceneGame/sceneSkinGame.exml";
            //
            /*this.runGame().catch(e => {
                console.log(e);
            })*/
            this.loadBoo = true;
        }
        else
        {
            this.foot.source="sceneGameBoot"+publicFun.ins+"_png";
            this.LeftTiao.source="sceneGameLeftTiao"+publicFun.ins+"_png";
            //////////////////////////////////////
            this.huanZhuang = new huanZhuang();
            this.huanZhuang.width=750;
            this.huanZhuang.height=1624;
            this.huanZhuang.x = this.stageW*0.5;
            this.huanZhuang.y = this.stageH*0.5+(1624-this.stageH)/2-138;
            this.addChild(this.huanZhuang);
            this.setChildIndex(this.huanZhuang,0);
            
            for(var i=1;i<=4;i++)
            {
                var armature = Object(this.parent).factory.buildArmature("sc1Ybtn");
                var armatureClip = armature.getDisplay();
                dragonBones.WorldClock.clock.add(armature);
                this.mu.getChildByName("btn"+i).addChild(armatureClip);
                armatureClip.x=this.mu.getChildByName("btn"+i).width/2;
                armatureClip.y=this.mu.getChildByName("btn"+i).height/2;
                for(var j=1;j<=4;j++)
                {
                    armature.getBone("btn"+j).visible=false;
                    if(j==i)
                    {
                        armature.getBone("btn"+j).visible=true;
                    }
                }
                this.arrBtnImg.push(armatureClip);
            }
        }
    }
    private async runGame() {
        await this.loadResource()
        this.createGameScene();
    }
    private async loadResource() {
        try {
            const loadingView = new LoadingUI();
            this.stage.addChild(loadingView);
            await RES.loadConfig("resource/default.res.json", "resource/");
            await RES.setMaxLoadingThread(6);
            await RES.loadGroup("scene1", 0, loadingView);
            this.stage.removeChild(loadingView);
        }
        catch (e) {
            console.error(e);
        }
    }
    private loadBoo = false;
    private stageW;
    private stageH;
}
