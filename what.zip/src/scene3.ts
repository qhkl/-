class Scene3 extends eui.Component {
    private onComplete():void{
        //
        for(var i=1;i<=6;i++)
        {
            this.mu.getChildByName("btn"+i).addEventListener( egret.TouchEvent.TOUCH_END,this.TouchFun,this);
        }
    }
    private mu;
    private TouchFun(evt:egret.TouchEvent): void {
        //alert(evt.currentTarget.name);
        var str:string=evt.currentTarget.name.split("n")[1];
        publicFun.ins=parseInt(str);
        Object(this.parent).sceneFun("SceneGame",false,false);
    }
    //
    public intFun()
    {
        //
    }
    public removeFun()
    {
        //
    }
    //-------------------------------/////-----------------------//
    protected createGameScene(): void {
        this.loadBoo = true;
        //
    }
    constructor() {
        super();
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
    }
    protected createChildren() {
        super.createChildren();
    }
    private onAddToStage(event: egret.Event) {
        //alert("sss");
        if(!this.loadBoo)
        {
            //
            this.stageW = this.stage.stageWidth;
            this.stageH = this.stage.stageHeight;
            //
            this.height=this.stageH;
            this.addEventListener(eui.UIEvent.COMPLETE,this.onComplete,this);
            this.skinName = "resource/assets/scene3/sceneSkin3.exml";
            //
            /*this.runGame().catch(e => {
                console.log(e);
            });*/
            this.loadBoo = true;
        }
        else
        {
            //
            //
        }
    }
    private async runGame() {
        await this.loadResource()
        this.createGameScene();
    }
    private async loadResource() {
        try {
            const loadingView = new LoadingUI();
            this.stage.addChild(loadingView);
            await RES.loadConfig("resource/default.res.json", "resource/");
            await RES.setMaxLoadingThread(6);
            await RES.loadGroup("scene1", 0, loadingView);
            this.stage.removeChild(loadingView);
        }
        catch (e) {
            console.error(e);
        }
    }
    private loadBoo = false;
    private stageW;
    private stageH;
}
