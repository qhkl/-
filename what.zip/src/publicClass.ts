class publicClass {
    public static loadingLogo=false;
}
class publicFun {
    public static ins=1;
    //位图
    public static createBitmapByName(name: string): egret.Bitmap {
        let result = new egret.Bitmap();
        let texture: egret.Texture = RES.getRes(name);
        result.texture = texture;
        return result;
    }
}
