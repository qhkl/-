class Main extends eui.UILayer {
    public mySceneArray:Array<any>=[];
    //
    public myScene;
    /**
     * 创建场景界面
     * Create scene interface
     */
    //
    public factory:dragonBones.EgretFactory = new dragonBones.EgretFactory();
    //
    public mySceneSwitchCompletion(){
        //
        //console.log('切换场景完成');
    }
    //
    private intFun()
    {
        //骨骼资源
        var skeletonData = RES.getRes("huanhuan_ske_json");
        //var textureData = RES.getRes("huanhuan_tex_json");
        //var texture = RES.getRes("huanhuan_tex_png");

        for(var i=0;i<=2;i++)
        {
            var textureData = RES.getRes("huanhuan_tex_"+i+"_json");
            var texture = RES.getRes("huanhuan_tex_"+i+"_png");
            this.factory.addTextureAtlasData(this.factory.parseTextureAtlasData(textureData,texture));
        }
        //骨骼模型
        this.factory.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(skeletonData));
        this.factory.addTextureAtlasData(this.factory.parseTextureAtlasData(textureData,texture));
    }
    private startFun()
    {
        //第一个场景
        this.sceneFun("Scene1",false,false);
    }
    //
    private mySceneFun()
    {
        this.mySceneArray=[["Scene1",null,new Scene1()],["Scene2",null,new Scene2()],["Scene3",null,new Scene3()],
                           ["SceneGame",null,new SceneGame()]];
    }
    //
    protected createGameScene(): void {
        //loadingLogo预加载属性
        publicClass.loadingLogo=true;
        //初始化数据
        this.intFun();
        //场景
        this.mySceneFun();
        //-------------//
        //计时器
        egret.startTick(this.onTicker, this);
        //开始
        this.startFun()
    }
    public sceneFun(e,ts,tp)
    {
        try
        {
            if(this.myScene)
            {
                if(ts)
                {
                    this.myScene.removeFun();
                }
                this.removeChild(this.myScene);
                this.myScene=null;
            }
            for(var i=0;i<this.mySceneArray.length;i++)
            {
                if(this.mySceneArray[i][0]==e)
                {
                    if(!this.mySceneArray[i][1])
                    {
                        this.mySceneArray[i][1]=this.mySceneArray[i][2];
                    }
                    this.myScene=this.mySceneArray[i][1];
                }
            }
            this.addChild(this.myScene);
            if(tp)
            {
                this.myScene.intFun();
            }
            this.mySceneSwitchCompletion();
        }
        catch(e)
        {
            alert("没有元素");
        }
    }
    ////////////////////////////////
    private _time:number;
    private onTicker(timeStamp:number) {

        if(!this._time) {
            this._time = timeStamp;
        }

        if(this.myScene)
        {
            try
            {
                this.myScene.Update();
            }
            catch(e)
            {

            }
        }

        var now = timeStamp;
        var pass = now - this._time;
        this._time = now;

        dragonBones.WorldClock.clock.advanceTime(pass / 1000);

        return false;
    }
    ///////////////////////////////////////////////////////////////
    protected createChildren(): void {
        super.createChildren();

        egret.lifecycle.addLifecycleListener((context) => {
            // custom lifecycle plugin
        })

        egret.lifecycle.onPause = () => {
            egret.ticker.pause();
        }

        egret.lifecycle.onResume = () => {
            egret.ticker.resume();
        }

        //inject the custom material parser
        //注入自定义的素材解析器
        let assetAdapter = new AssetAdapter();
        egret.registerImplementation("eui.IAssetAdapter", assetAdapter);
        egret.registerImplementation("eui.IThemeAdapter", new ThemeAdapter());


        this.runGame().catch(e => {
            console.log(e);
        })
    }

    private async runGame() {
        await this.loadResource()
        this.createGameScene();
    }

    private async loadResource() {
        try {
            const loadingView = new LoadingUI();
            this.stage.addChild(loadingView);
            await RES.loadConfig("resource/default.res.json", "resource/");
            await this.loadTheme();
            await RES.loadGroup("preload", 0, loadingView);
            this.stage.removeChild(loadingView);
        }
        catch (e) {
            console.error(e);
        }
    }

    private loadTheme() {
        return new Promise((resolve, reject) => {
            // load skin theme configuration file, you can manually modify the file. And replace the default skin.
            //加载皮肤主题配置文件,可以手动修改这个文件。替换默认皮肤。
            let theme = new eui.Theme("resource/default.thm.json", this.stage);
            theme.addEventListener(eui.UIEvent.COMPLETE, () => {
                resolve();
            }, this);

        })
    }
}
